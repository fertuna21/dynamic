from django.shortcuts import render, HttpResponse
from .models import *
# Create your views here.


def home(request):
   info = CompanyInformation.objects.first()
   products = Product.objects.filter(category_name='none')
   
   data ={
      
      'info':info,
      'products':products
   }
   
   return render(request, 'home.html',data)

def about(request):
   
   return HttpResponse('about page')
   

   

def contact_us(request):
   return HttpResponse('contact_us page')

def product(request):
   
   info = CompanyInformation.objects.first()
   products = Product.objects.all()
   
   data ={
      
      'info':info,
      'products':products
   }
   return render(request, 'product.html', data)