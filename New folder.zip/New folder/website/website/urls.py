
from django.contrib import admin
from django.urls import path
from product.views import home, contact_us, about, product
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    # Define the name 'home' for the URL pattern
    path('home/', home, name='home'),
    path('about/', about, name='about'),
    path('contact/', contact_us, name='contact'),
    path('product/', product, name='product'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
